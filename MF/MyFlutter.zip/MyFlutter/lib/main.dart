import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key})
      : super(
            key:
                key); // Perbaikan sintaks: menambahkan tanda tanya dan menambahkan kata kunci Key

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Untuk menghilangkan tanda debug
      title: 'Flutter Demo', // Merubah judul aplikasi
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text("Flutter Demo"), // Merubah judul app bar
          backgroundColor: Colors.blue,
        ),
        body: SafeArea(
          child: Container(
            margin: EdgeInsets.symmetric(
                horizontal:
                    45.0), // Menggunakan EdgeInsets.symmetric untuk menyederhanakan penulisan
            padding: EdgeInsets.only(
                top: 50.0), // Menghapus properti yang tidak diperlukan
            child: Column(
              children: <Widget>[
                Image(
                  image: AssetImage('assets/images/payment.png'),
                  height: 300,
                ),
                Text("Payment Gateway"),
                Text("Save Your Money"),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
